//
// Created by Rakolcza Peter on 2019. 11. 25..
//

#ifndef BME_SCHOOTER_JATEKMENET_H
#define BME_SCHOOTER_JATEKMENET_H

#include "kozos.h"

void jatekFrissites(Peldany *jatekos, Jatek *jatek, Palya *palya, SDL_Texture *texture, SDL_Texture *ellenseg, SDL_Texture *elet, SDL_Texture *tolteny, Lovedek **lovedek, PowerUp **powerup);

#endif //BME_SCHOOTER_JATEKMENET_H
