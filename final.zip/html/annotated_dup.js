var annotated_dup =
[
    [ "DebugmallocData", "struct_debugmalloc_data.html", "struct_debugmalloc_data" ],
    [ "DebugmallocElem", "struct_debugmalloc_elem.html", "struct_debugmalloc_elem" ],
    [ "Eger", "struct_eger.html", "struct_eger" ],
    [ "Eredmenyek", "struct_eredmenyek.html", "struct_eredmenyek" ],
    [ "Jatek", "struct_jatek.html", "struct_jatek" ],
    [ "Lovedek", "struct_lovedek.html", "struct_lovedek" ],
    [ "Palya", "struct_palya.html", "struct_palya" ],
    [ "Peldany", "struct_peldany.html", "struct_peldany" ],
    [ "PowerUp", "struct_power_up.html", "struct_power_up" ]
];