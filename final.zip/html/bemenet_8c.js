var bemenet_8c =
[
    [ "elengedve", "bemenet_8c.html#ab0eb31f11025ae1837c1f1e1db774ece", null ],
    [ "gombFel", "bemenet_8c.html#a4534580e58e1b0e2433a86dd8e0057b6", null ],
    [ "gombLe", "bemenet_8c.html#a270f3bd1f2452e8d8247ff48ffce7fc4", null ],
    [ "lenyomva", "bemenet_8c.html#a77eb736b57a894f1f8287f623d93213c", null ]
];