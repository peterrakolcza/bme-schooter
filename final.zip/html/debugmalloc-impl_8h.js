var debugmalloc_impl_8h =
[
    [ "DebugmallocElem", "struct_debugmalloc_elem.html", "struct_debugmalloc_elem" ],
    [ "DebugmallocData", "struct_debugmalloc_data.html", "struct_debugmalloc_data" ],
    [ "DebugmallocData", "debugmalloc-impl_8h.html#a67d1b20cf90f70013df57939824f95d8", null ],
    [ "DebugmallocElem", "debugmalloc-impl_8h.html#a46ff63ffc3d2d4c1fc67a0f8c6fef6d4", null ],
    [ "debugmalloc_canary_size", "debugmalloc-impl_8h.html#a06fc87d81c62e9abb8790b6e5713c55bab345007cf28a2516c0ba24371a400520", null ],
    [ "debugmalloc_canary_char", "debugmalloc-impl_8h.html#adf764cbdea00d65edcd07bb9953ad2b7a8e3d5ad8628140edd887b8920f521cfd", null ],
    [ "debugmalloc_tablesize", "debugmalloc-impl_8h.html#a99fb83031ce9923c84392b4e92f956b5a40803f0d5a26a349a78cbd998cb8a2a1", null ]
];