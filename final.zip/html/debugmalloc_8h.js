var debugmalloc_8h =
[
    [ "calloc", "debugmalloc_8h.html#ac07b71d27b6b37e81ac3a4c230f5794e", null ],
    [ "free", "debugmalloc_8h.html#aa7943e5d135734f6801bebcc37401fc0", null ],
    [ "malloc", "debugmalloc_8h.html#a535b58ab5aa48e2e86073e334d43fd32", null ],
    [ "realloc", "debugmalloc_8h.html#a54df243d89c451240697d7d3afb5663f", null ]
];