var dir_154a68f9ce7db912c91b397085ff0f2b =
[
    [ "bemenet.c", "bemenet_8c.html", "bemenet_8c" ],
    [ "bemenet.h", "bemenet_8h.html", "bemenet_8h" ],
    [ "debugmalloc-impl.h", "debugmalloc-impl_8h.html", "debugmalloc-impl_8h" ],
    [ "debugmalloc.h", "debugmalloc_8h.html", "debugmalloc_8h" ],
    [ "eredmenyek.c", "eredmenyek_8c.html", "eredmenyek_8c" ],
    [ "eredmenyek.h", "eredmenyek_8h.html", "eredmenyek_8h" ],
    [ "init.c", "init_8c.html", "init_8c" ],
    [ "init.h", "init_8h.html", "init_8h" ],
    [ "jatekmenet.c", "jatekmenet_8c.html", "jatekmenet_8c" ],
    [ "jatekmenet.h", "jatekmenet_8h.html", "jatekmenet_8h" ],
    [ "kozos.h", "kozos_8h.html", "kozos_8h" ],
    [ "main.c", "main_8c.html", "main_8c" ],
    [ "rajzolas.c", "rajzolas_8c.html", "rajzolas_8c" ],
    [ "rajzolas.h", "rajzolas_8h.html", "rajzolas_8h" ]
];