var eredmenyek_8h =
[
    [ "beolvasas", "eredmenyek_8h.html#af61824ee9a7debde4998107577a2df3a", null ],
    [ "feluliras", "eredmenyek_8h.html#a0e6447e2fb9586da61061c89ad5d6ef8", null ],
    [ "kiiras", "eredmenyek_8h.html#a49dd21f57a577ded931320b548f09abd", null ],
    [ "szovegBeirasa", "eredmenyek_8h.html#a937ff0b64af97202f6d091b4d42c1dde", null ]
];