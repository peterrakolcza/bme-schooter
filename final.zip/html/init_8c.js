var init_8c =
[
    [ "felkeszites", "init_8c.html#a9a24be9b57feeafef19f7eeabc4ee457", null ],
    [ "felszabaditas", "init_8c.html#a184f135d3537c8da858eb0e5fbdf06c9", null ],
    [ "init", "init_8c.html#a9782d222a4bd538f19ac4ff66adf6fbc", null ],
    [ "initJatekos", "init_8c.html#ac70e78ff23ae907182f9c36ca4909f3e", null ],
    [ "initPalya", "init_8c.html#a7be4f5ad177600267e562f6cbd1a71ef", null ],
    [ "initTTF", "init_8c.html#a7479fc03a6fa1d448a130e94760b01fe", null ],
    [ "kepernyo", "init_8c.html#a5c55e2174fe13673b2fc4b78b5f15b0c", null ],
    [ "loadImage", "init_8c.html#ae35b3eaf987f2497e5149463993891e7", null ],
    [ "torles", "init_8c.html#a1dce24c6c71880df27dca2e22caf5af8", null ]
];