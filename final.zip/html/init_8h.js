var init_8h =
[
    [ "felkeszites", "init_8h.html#a9a24be9b57feeafef19f7eeabc4ee457", null ],
    [ "felszabaditas", "init_8h.html#a8181a6044f8cc0b9d55f4658bae8c553", null ],
    [ "init", "init_8h.html#a9782d222a4bd538f19ac4ff66adf6fbc", null ],
    [ "initPalya", "init_8h.html#a7be4f5ad177600267e562f6cbd1a71ef", null ],
    [ "initTTF", "init_8h.html#a7479fc03a6fa1d448a130e94760b01fe", null ],
    [ "kepernyo", "init_8h.html#a5c55e2174fe13673b2fc4b78b5f15b0c", null ],
    [ "loadImage", "init_8h.html#ae35b3eaf987f2497e5149463993891e7", null ],
    [ "torles", "init_8h.html#a1dce24c6c71880df27dca2e22caf5af8", null ]
];