var jatekmenet_8c =
[
    [ "calcSlope", "jatekmenet_8c.html#a29bbc90d229456859175070f30a35c60", null ],
    [ "ellensegHozzaad", "jatekmenet_8c.html#a344d90b5286b19078190eb2880957376", null ],
    [ "getDistance", "jatekmenet_8c.html#a6e47f06cebe1879b672fa23a7c3eae70", null ],
    [ "halal", "jatekmenet_8c.html#a63a9a3c2ff8f1d5c3f1fba536fab9979", null ],
    [ "hozzaadRandomPowerup", "jatekmenet_8c.html#ab80e337c3d534cd845b13f21deca1ea9", null ],
    [ "jatekFrissites", "jatekmenet_8c.html#ae5be530bbfea7fb94a0f93d053c03a1a", null ],
    [ "jatekosFrissites", "jatekmenet_8c.html#a2a8f1e5968d81f406b967878d4ee54bd", null ],
    [ "lovedekFrissites", "jatekmenet_8c.html#a3c1770510454a81b919b86087abb6acf", null ],
    [ "lovedekTalaltE", "jatekmenet_8c.html#a1d588771007ecc0489d32136497b69a5", null ],
    [ "loves", "jatekmenet_8c.html#a7dc55162329531cf78c40697c8e843ed", null ],
    [ "peldanyFrissites", "jatekmenet_8c.html#a4c047dc54de141d5766990c8ed554540", null ],
    [ "powerupFrissites", "jatekmenet_8c.html#aba6f73627c2d24fae7c9043c09e8ced6", null ],
    [ "powerupLetrehoz", "jatekmenet_8c.html#ab6b2d474726256cd4dbc87fabbb1145d", null ],
    [ "spawnEllenseg", "jatekmenet_8c.html#a2d5b039c8924568620b8b643fdf8a55a", null ],
    [ "szog", "jatekmenet_8c.html#a8fad92fd89a54b333dbf432d8371ce8d", null ],
    [ "tick", "jatekmenet_8c.html#a3ec10aa72d10025566f4df4185027e05", null ]
];