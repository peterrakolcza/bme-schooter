var jatekmenet_8h =
[
    [ "jatekFrissites", "jatekmenet_8h.html#a407f039e6efdb927ebe5d6df289667b1", null ]
];