var kozos_8h =
[
    [ "Eger", "struct_eger.html", "struct_eger" ],
    [ "Palya", "struct_palya.html", "struct_palya" ],
    [ "Peldany", "struct_peldany.html", "struct_peldany" ],
    [ "PowerUp", "struct_power_up.html", "struct_power_up" ],
    [ "Lovedek", "struct_lovedek.html", "struct_lovedek" ],
    [ "Jatek", "struct_jatek.html", "struct_jatek" ],
    [ "Eredmenyek", "struct_eredmenyek.html", "struct_eredmenyek" ],
    [ "MAX", "kozos_8h.html#afa99ec4acc4ecb2dc3c2d05da15d0e3f", null ],
    [ "MIN", "kozos_8h.html#a3acffbd305ee72dcd4593c0d8af64a4f", null ],
    [ "PI", "kozos_8h.html#a598a3330b3c21701223ee0ca14316eca", null ],
    [ "SCREEN_HEIGHT", "kozos_8h.html#a6974d08a74da681b3957b2fead2608b8", null ],
    [ "SCREEN_WIDTH", "kozos_8h.html#a2cd109632a6dcccaa80b43561b1ab700", null ],
    [ "Eger", "kozos_8h.html#a5a185307919924584e258213c5bdc413", null ],
    [ "Eredmenyek", "kozos_8h.html#a25b675797368da2771e6624d4f82c969", null ],
    [ "Fegyver", "kozos_8h.html#af9275be7cde56e11f0400be4a8d35296", null ],
    [ "Jatek", "kozos_8h.html#a135b13c622a4434f9f2e8895f1f4b709", null ],
    [ "Lovedek", "kozos_8h.html#a550ab1650a2ac0c47502400b86048890", null ],
    [ "Palya", "kozos_8h.html#aed8de916f807ff6e7fe953593a327555", null ],
    [ "Peldany", "kozos_8h.html#a682e744424a5e081acfb38a9234ac567", null ],
    [ "PowerUp", "kozos_8h.html#a80413c65dfc2583386bac5300021137c", null ],
    [ "Fegyver", "kozos_8h.html#a53ce3de7207d3d49119025c149070e62", [
      [ "GepFegyver", "kozos_8h.html#a53ce3de7207d3d49119025c149070e62a1e10152f1e85232ce8a3ff2b3ad1030b", null ],
      [ "Pisztoly", "kozos_8h.html#a53ce3de7207d3d49119025c149070e62a03482c2d67eebb608e15c6182ceb43a0", null ]
    ] ]
];