var rajzolas_8c =
[
    [ "blit", "rajzolas_8c.html#a21fc9f3e80f35503f4171bf26bbecbcb", null ],
    [ "blitRotated", "rajzolas_8c.html#ad9b6209341e1184407414f70328a8a4d", null ],
    [ "fokepernyo", "rajzolas_8c.html#adb21ceef0b8c7ce9627f14a0b9423855", null ],
    [ "HUDrajzolas", "rajzolas_8c.html#a5bc0e01e4f523239a3223a166cdb6562", null ],
    [ "legjobbEredmenyekKepernyo", "rajzolas_8c.html#a4330446548933700545febd173b01e0c", null ],
    [ "legjobbNev", "rajzolas_8c.html#a69099757c077e11f819d5b7b17ef9701", null ],
    [ "mintazat", "rajzolas_8c.html#aa53d004393e5249fb991c218cc71fe24", null ],
    [ "rajz", "rajzolas_8c.html#a6fd0e900811519c1ff0d02c0c0a91d8c", null ],
    [ "szovegRajzolas", "rajzolas_8c.html#a4bd2b513806bcf0cfe9e034074353102", null ]
];