var rajzolas_8h =
[
    [ "fokepernyo", "rajzolas_8h.html#adb21ceef0b8c7ce9627f14a0b9423855", null ],
    [ "legjobbEredmenyekKepernyo", "rajzolas_8h.html#a4330446548933700545febd173b01e0c", null ],
    [ "legjobbNev", "rajzolas_8h.html#a69099757c077e11f819d5b7b17ef9701", null ],
    [ "rajz", "rajzolas_8h.html#a6fd0e900811519c1ff0d02c0c0a91d8c", null ]
];