var searchData=
[
  ['calcslope_7',['calcSlope',['../jatekmenet_8c.html#a29bbc90d229456859175070f30a35c60',1,'jatekmenet.c']]],
  ['calloc_8',['calloc',['../debugmalloc_8h.html#ac07b71d27b6b37e81ac3a4c230f5794e',1,'debugmalloc.h']]],
  ['capframerate_9',['capFrameRate',['../main_8c.html#a4ca2512f5a6840b19b6143ad01c315a0',1,'main.c']]]
];
