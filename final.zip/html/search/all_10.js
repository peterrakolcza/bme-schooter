var searchData=
[
  ['screen_5fheight_97',['SCREEN_HEIGHT',['../kozos_8h.html#a6974d08a74da681b3957b2fead2608b8',1,'kozos.h']]],
  ['screen_5fwidth_98',['SCREEN_WIDTH',['../kozos_8h.html#a2cd109632a6dcccaa80b43561b1ab700',1,'kozos.h']]],
  ['size_99',['size',['../struct_debugmalloc_elem.html#a854352f53b148adc24983a58a1866d66',1,'DebugmallocElem']]],
  ['spawnellenseg_100',['spawnEllenseg',['../jatekmenet_8c.html#a2d5b039c8924568620b8b643fdf8a55a',1,'jatekmenet.c']]],
  ['spawnidozito_101',['spawnIdozito',['../struct_palya.html#a10254401739f948a8c706a6bdb1d5728',1,'Palya']]],
  ['szog_102',['szog',['../struct_peldany.html#acf721b2887c9dab2acedce755a6b29ec',1,'Peldany::szog()'],['../struct_lovedek.html#acf721b2887c9dab2acedce755a6b29ec',1,'Lovedek::szog()'],['../jatekmenet_8c.html#a8fad92fd89a54b333dbf432d8371ce8d',1,'szog():&#160;jatekmenet.c']]],
  ['szovegbeirasa_103',['szovegBeirasa',['../eredmenyek_8c.html#a937ff0b64af97202f6d091b4d42c1dde',1,'szovegBeirasa(Jatek *jatek, bool *vege):&#160;eredmenyek.c'],['../eredmenyek_8h.html#a937ff0b64af97202f6d091b4d42c1dde',1,'szovegBeirasa(Jatek *jatek, bool *vege):&#160;eredmenyek.c']]],
  ['szovegrajzolas_104',['szovegRajzolas',['../rajzolas_8c.html#a4bd2b513806bcf0cfe9e034074353102',1,'rajzolas.c']]]
];
