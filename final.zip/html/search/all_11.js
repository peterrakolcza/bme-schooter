var searchData=
[
  ['tail_105',['tail',['../struct_debugmalloc_data.html#addc8e0dcf96cbf596961383aabf9ec97',1,'DebugmallocData']]],
  ['texture_106',['texture',['../struct_peldany.html#a859b8efbf9abe8e82757ee5c75a0c97c',1,'Peldany::texture()'],['../struct_power_up.html#a859b8efbf9abe8e82757ee5c75a0c97c',1,'PowerUp::texture()'],['../struct_lovedek.html#a859b8efbf9abe8e82757ee5c75a0c97c',1,'Lovedek::texture()']]],
  ['tick_107',['tick',['../jatekmenet_8c.html#a3ec10aa72d10025566f4df4185027e05',1,'jatekmenet.c']]],
  ['tipus_108',['tipus',['../struct_power_up.html#a79399c4d986e6b87e222cbf38b392913',1,'PowerUp']]],
  ['tolteny_109',['tolteny',['../struct_palya.html#ae4ef33e0e2ef855554f77eabb40c73a9',1,'Palya']]],
  ['torles_110',['torles',['../init_8c.html#a1dce24c6c71880df27dca2e22caf5af8',1,'torles(SDL_Renderer *renderer, SDL_Window *window):&#160;init.c'],['../init_8h.html#a1dce24c6c71880df27dca2e22caf5af8',1,'torles(SDL_Renderer *renderer, SDL_Window *window):&#160;init.c']]]
];
