var searchData=
[
  ['fegyver_27',['fegyver',['../struct_peldany.html#a01c600a575ec89d64a85336929d4deb0',1,'Peldany::fegyver()'],['../kozos_8h.html#a53ce3de7207d3d49119025c149070e62',1,'Fegyver():&#160;kozos.h'],['../kozos_8h.html#af9275be7cde56e11f0400be4a8d35296',1,'Fegyver():&#160;kozos.h']]],
  ['felkeszites_28',['felkeszites',['../init_8c.html#a9a24be9b57feeafef19f7eeabc4ee457',1,'felkeszites(SDL_Renderer *renderer):&#160;init.c'],['../init_8h.html#a9a24be9b57feeafef19f7eeabc4ee457',1,'felkeszites(SDL_Renderer *renderer):&#160;init.c']]],
  ['felszabaditas_29',['felszabaditas',['../init_8c.html#a184f135d3537c8da858eb0e5fbdf06c9',1,'felszabaditas(Peldany **jatekos, Lovedek **lovedek, PowerUp **powerup):&#160;init.c'],['../init_8h.html#a8181a6044f8cc0b9d55f4658bae8c553',1,'felszabaditas(Peldany **jatekos, Lovedek **lovedek, PowerUp **powerUp):&#160;init.c']]],
  ['feluliras_30',['feluliras',['../eredmenyek_8c.html#a0e6447e2fb9586da61061c89ad5d6ef8',1,'feluliras(Eredmenyek tomb[], int pontszam, char nev[], int i, int index):&#160;eredmenyek.c'],['../eredmenyek_8h.html#a0e6447e2fb9586da61061c89ad5d6ef8',1,'feluliras(Eredmenyek tomb[], int pontszam, char nev[], int i, int index):&#160;eredmenyek.c']]],
  ['file_31',['file',['../struct_debugmalloc_elem.html#a353d29f9f9cc0db6fca9d49b5f88d34d',1,'DebugmallocElem']]],
  ['fokepernyo_32',['fokepernyo',['../rajzolas_8c.html#adb21ceef0b8c7ce9627f14a0b9423855',1,'fokepernyo(SDL_Renderer *renderer, TTF_Font *font, SDL_Texture *celzo, Jatek *jatek, SDL_Texture *fokepernyoTexture, SDL_Texture *grid):&#160;rajzolas.c'],['../rajzolas_8h.html#adb21ceef0b8c7ce9627f14a0b9423855',1,'fokepernyo(SDL_Renderer *renderer, TTF_Font *font, SDL_Texture *celzo, Jatek *jatek, SDL_Texture *fokepernyoTexture, SDL_Texture *grid):&#160;rajzolas.c']]],
  ['free_33',['free',['../debugmalloc_8h.html#aa7943e5d135734f6801bebcc37401fc0',1,'debugmalloc.h']]],
  ['func_34',['func',['../struct_debugmalloc_elem.html#ac8a2334cf5c64b1f708ced23ef569db4',1,'DebugmallocElem']]]
];
