var searchData=
[
  ['kepernyo_58',['kepernyo',['../init_8c.html#a5c55e2174fe13673b2fc4b78b5f15b0c',1,'kepernyo(SDL_Renderer *renderer):&#160;init.c'],['../init_8h.html#a5c55e2174fe13673b2fc4b78b5f15b0c',1,'kepernyo(SDL_Renderer *renderer):&#160;init.c']]],
  ['kiiras_59',['kiiras',['../eredmenyek_8c.html#a49dd21f57a577ded931320b548f09abd',1,'kiiras(Eredmenyek tomb[]):&#160;eredmenyek.c'],['../eredmenyek_8h.html#a49dd21f57a577ded931320b548f09abd',1,'kiiras(Eredmenyek tomb[]):&#160;eredmenyek.c']]],
  ['kov_60',['kov',['../struct_peldany.html#a5dd3001677caf0537f6f3dcfb903d766',1,'Peldany::kov()'],['../struct_power_up.html#af9c2d469f617545127cfd0667354f9a2',1,'PowerUp::kov()'],['../struct_lovedek.html#a5d11984f43577221fcba4fccf49cf14a',1,'Lovedek::kov()']]],
  ['kozos_2eh_61',['kozos.h',['../kozos_8h.html',1,'']]]
];
