var searchData=
[
  ['legjobberedmenyekkepernyo_62',['legjobbEredmenyekKepernyo',['../rajzolas_8c.html#a4330446548933700545febd173b01e0c',1,'legjobbEredmenyekKepernyo(SDL_Renderer *renderer, TTF_Font *font, SDL_Texture *celzo, Jatek *jatek, SDL_Texture *fokepernyoTexture, SDL_Texture *grid, Eredmenyek tomb[]):&#160;rajzolas.c'],['../rajzolas_8h.html#a4330446548933700545febd173b01e0c',1,'legjobbEredmenyekKepernyo(SDL_Renderer *renderer, TTF_Font *font, SDL_Texture *celzo, Jatek *jatek, SDL_Texture *fokepernyoTexture, SDL_Texture *grid, Eredmenyek tomb[]):&#160;rajzolas.c']]],
  ['legjobbnev_63',['legjobbNev',['../rajzolas_8c.html#a69099757c077e11f819d5b7b17ef9701',1,'legjobbNev(SDL_Renderer *renderer, TTF_Font *font, char nev[]):&#160;rajzolas.c'],['../rajzolas_8h.html#a69099757c077e11f819d5b7b17ef9701',1,'legjobbNev(SDL_Renderer *renderer, TTF_Font *font, char nev[]):&#160;rajzolas.c']]],
  ['lenyomva_64',['lenyomva',['../bemenet_8c.html#a77eb736b57a894f1f8287f623d93213c',1,'lenyomva(SDL_KeyboardEvent *esemeny, Jatek *jatek):&#160;bemenet.c'],['../bemenet_8h.html#a77eb736b57a894f1f8287f623d93213c',1,'lenyomva(SDL_KeyboardEvent *esemeny, Jatek *jatek):&#160;bemenet.c']]],
  ['line_65',['line',['../struct_debugmalloc_elem.html#a05ef0c4dbeec4fc8ccb225de9c26d896',1,'DebugmallocElem']]],
  ['loadimage_66',['loadImage',['../init_8c.html#ae35b3eaf987f2497e5149463993891e7',1,'loadImage(SDL_Renderer *renderer, char path[]):&#160;init.c'],['../init_8h.html#ae35b3eaf987f2497e5149463993891e7',1,'loadImage(SDL_Renderer *renderer, char path[]):&#160;init.c']]],
  ['logfile_67',['logfile',['../struct_debugmalloc_data.html#af5ff893eedb28514f6f69c3687ca893b',1,'DebugmallocData']]],
  ['lovedek_68',['Lovedek',['../struct_lovedek.html',1,'Lovedek'],['../kozos_8h.html#a550ab1650a2ac0c47502400b86048890',1,'Lovedek():&#160;kozos.h']]],
  ['lovedekfrissites_69',['lovedekFrissites',['../jatekmenet_8c.html#a3c1770510454a81b919b86087abb6acf',1,'jatekmenet.c']]],
  ['lovedektalalte_70',['lovedekTalaltE',['../jatekmenet_8c.html#a1d588771007ecc0489d32136497b69a5',1,'jatekmenet.c']]],
  ['loves_71',['loves',['../jatekmenet_8c.html#a7dc55162329531cf78c40697c8e843ed',1,'jatekmenet.c']]]
];
