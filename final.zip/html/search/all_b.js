var searchData=
[
  ['main_72',['main',['../main_8c.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main.c']]],
  ['main_2ec_73',['main.c',['../main_8c.html',1,'']]],
  ['malloc_74',['malloc',['../debugmalloc_8h.html#a535b58ab5aa48e2e86073e334d43fd32',1,'debugmalloc.h']]],
  ['max_75',['MAX',['../kozos_8h.html#afa99ec4acc4ecb2dc3c2d05da15d0e3f',1,'kozos.h']]],
  ['min_76',['MIN',['../kozos_8h.html#a3acffbd305ee72dcd4593c0d8af64a4f',1,'kozos.h']]],
  ['mintazat_77',['mintazat',['../rajzolas_8c.html#aa53d004393e5249fb991c218cc71fe24',1,'rajzolas.c']]]
];
