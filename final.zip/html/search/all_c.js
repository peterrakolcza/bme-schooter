var searchData=
[
  ['nev_78',['nev',['../struct_eredmenyek.html#a074ffd3ef2ad10d0979161d59df06d07',1,'Eredmenyek']]],
  ['next_79',['next',['../struct_debugmalloc_elem.html#a485117ad705ab85f760fa96176f5825a',1,'DebugmallocElem']]]
];
