var searchData=
[
  ['rajz_92',['rajz',['../rajzolas_8c.html#a6fd0e900811519c1ff0d02c0c0a91d8c',1,'rajz(SDL_Texture *celzo, SDL_Texture *grid, SDL_Texture *hatter, Jatek *jatek, Peldany *jatekos, Lovedek *lovedek, PowerUp *powerup, Palya *palya, SDL_Renderer *renderer, TTF_Font *font):&#160;rajzolas.c'],['../rajzolas_8h.html#a6fd0e900811519c1ff0d02c0c0a91d8c',1,'rajz(SDL_Texture *celzo, SDL_Texture *grid, SDL_Texture *hatter, Jatek *jatek, Peldany *jatekos, Lovedek *lovedek, PowerUp *powerup, Palya *palya, SDL_Renderer *renderer, TTF_Font *font):&#160;rajzolas.c']]],
  ['rajzolas_2ec_93',['rajzolas.c',['../rajzolas_8c.html',1,'']]],
  ['rajzolas_2eh_94',['rajzolas.h',['../rajzolas_8h.html',1,'']]],
  ['real_5fmem_95',['real_mem',['../struct_debugmalloc_elem.html#ae241706d126e0114e48ce7c4083d93d1',1,'DebugmallocElem']]],
  ['realloc_96',['realloc',['../debugmalloc_8h.html#a54df243d89c451240697d7d3afb5663f',1,'debugmalloc.h']]]
];
