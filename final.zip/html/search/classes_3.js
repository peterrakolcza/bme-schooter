var searchData=
[
  ['lovedek_121',['Lovedek',['../struct_lovedek.html',1,'']]]
];
