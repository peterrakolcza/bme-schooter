var searchData=
[
  ['malloc_238',['malloc',['../debugmalloc_8h.html#a535b58ab5aa48e2e86073e334d43fd32',1,'debugmalloc.h']]],
  ['max_239',['MAX',['../kozos_8h.html#afa99ec4acc4ecb2dc3c2d05da15d0e3f',1,'kozos.h']]],
  ['min_240',['MIN',['../kozos_8h.html#a3acffbd305ee72dcd4593c0d8af64a4f',1,'kozos.h']]]
];
