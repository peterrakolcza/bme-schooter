var searchData=
[
  ['pi_241',['PI',['../kozos_8h.html#a598a3330b3c21701223ee0ca14316eca',1,'kozos.h']]]
];
