var searchData=
[
  ['screen_5fheight_243',['SCREEN_HEIGHT',['../kozos_8h.html#a6974d08a74da681b3957b2fead2608b8',1,'kozos.h']]],
  ['screen_5fwidth_244',['SCREEN_WIDTH',['../kozos_8h.html#a2cd109632a6dcccaa80b43561b1ab700',1,'kozos.h']]]
];
