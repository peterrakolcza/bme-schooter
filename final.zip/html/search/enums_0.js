var searchData=
[
  ['fegyver_230',['Fegyver',['../kozos_8h.html#a53ce3de7207d3d49119025c149070e62',1,'kozos.h']]]
];
