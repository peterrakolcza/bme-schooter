var searchData=
[
  ['debugmalloc_5fcanary_5fchar_231',['debugmalloc_canary_char',['../debugmalloc-impl_8h.html#adf764cbdea00d65edcd07bb9953ad2b7a8e3d5ad8628140edd887b8920f521cfd',1,'debugmalloc-impl.h']]],
  ['debugmalloc_5fcanary_5fsize_232',['debugmalloc_canary_size',['../debugmalloc-impl_8h.html#a06fc87d81c62e9abb8790b6e5713c55bab345007cf28a2516c0ba24371a400520',1,'debugmalloc-impl.h']]],
  ['debugmalloc_5ftablesize_233',['debugmalloc_tablesize',['../debugmalloc-impl_8h.html#a99fb83031ce9923c84392b4e92f956b5a40803f0d5a26a349a78cbd998cb8a2a1',1,'debugmalloc-impl.h']]]
];
