var searchData=
[
  ['gepfegyver_234',['GepFegyver',['../kozos_8h.html#a53ce3de7207d3d49119025c149070e62a1e10152f1e85232ce8a3ff2b3ad1030b',1,'kozos.h']]]
];
