var searchData=
[
  ['eredmenyek_2ec_129',['eredmenyek.c',['../eredmenyek_8c.html',1,'']]],
  ['eredmenyek_2eh_130',['eredmenyek.h',['../eredmenyek_8h.html',1,'']]]
];
