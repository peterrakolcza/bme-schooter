var searchData=
[
  ['init_2ec_131',['init.c',['../init_8c.html',1,'']]],
  ['init_2eh_132',['init.h',['../init_8h.html',1,'']]]
];
