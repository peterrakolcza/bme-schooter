var searchData=
[
  ['beolvasas_139',['beolvasas',['../eredmenyek_8c.html#af61824ee9a7debde4998107577a2df3a',1,'beolvasas(Eredmenyek tomb[]):&#160;eredmenyek.c'],['../eredmenyek_8h.html#af61824ee9a7debde4998107577a2df3a',1,'beolvasas(Eredmenyek tomb[]):&#160;eredmenyek.c']]],
  ['blit_140',['blit',['../rajzolas_8c.html#a21fc9f3e80f35503f4171bf26bbecbcb',1,'rajzolas.c']]],
  ['blitrotated_141',['blitRotated',['../rajzolas_8c.html#ad9b6209341e1184407414f70328a8a4d',1,'rajzolas.c']]]
];
