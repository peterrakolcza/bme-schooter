var searchData=
[
  ['calcslope_142',['calcSlope',['../jatekmenet_8c.html#a29bbc90d229456859175070f30a35c60',1,'jatekmenet.c']]],
  ['capframerate_143',['capFrameRate',['../main_8c.html#a4ca2512f5a6840b19b6143ad01c315a0',1,'main.c']]]
];
