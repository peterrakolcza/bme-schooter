var searchData=
[
  ['elengedve_144',['elengedve',['../bemenet_8c.html#ab0eb31f11025ae1837c1f1e1db774ece',1,'elengedve(SDL_KeyboardEvent *esemeny, Jatek *jatek):&#160;bemenet.c'],['../bemenet_8h.html#ab0eb31f11025ae1837c1f1e1db774ece',1,'elengedve(SDL_KeyboardEvent *esemeny, Jatek *jatek):&#160;bemenet.c']]],
  ['ellenseghozzaad_145',['ellensegHozzaad',['../jatekmenet_8c.html#a344d90b5286b19078190eb2880957376',1,'jatekmenet.c']]]
];
