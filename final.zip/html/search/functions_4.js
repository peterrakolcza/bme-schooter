var searchData=
[
  ['getdistance_150',['getDistance',['../jatekmenet_8c.html#a6e47f06cebe1879b672fa23a7c3eae70',1,'jatekmenet.c']]],
  ['gombfel_151',['gombFel',['../bemenet_8c.html#a4534580e58e1b0e2433a86dd8e0057b6',1,'gombFel(SDL_MouseButtonEvent *es, Jatek *jatek):&#160;bemenet.c'],['../bemenet_8h.html#a4534580e58e1b0e2433a86dd8e0057b6',1,'gombFel(SDL_MouseButtonEvent *es, Jatek *jatek):&#160;bemenet.c']]],
  ['gomble_152',['gombLe',['../bemenet_8c.html#a270f3bd1f2452e8d8247ff48ffce7fc4',1,'gombLe(SDL_MouseButtonEvent *es, Jatek *jatek):&#160;bemenet.c'],['../bemenet_8h.html#a270f3bd1f2452e8d8247ff48ffce7fc4',1,'gombLe(SDL_MouseButtonEvent *es, Jatek *jatek):&#160;bemenet.c']]]
];
