var searchData=
[
  ['init_156',['init',['../init_8c.html#a9782d222a4bd538f19ac4ff66adf6fbc',1,'init(SDL_Renderer **renderer1, SDL_Window **window1):&#160;init.c'],['../init_8h.html#a9782d222a4bd538f19ac4ff66adf6fbc',1,'init(SDL_Renderer **renderer1, SDL_Window **window1):&#160;init.c']]],
  ['initjatekos_157',['initJatekos',['../init_8c.html#ac70e78ff23ae907182f9c36ca4909f3e',1,'init.c']]],
  ['initpalya_158',['initPalya',['../init_8c.html#a7be4f5ad177600267e562f6cbd1a71ef',1,'initPalya(SDL_Renderer *renderer, Peldany **jatekos, Palya *palya, Jatek *jatek):&#160;init.c'],['../init_8h.html#a7be4f5ad177600267e562f6cbd1a71ef',1,'initPalya(SDL_Renderer *renderer, Peldany **jatekos, Palya *palya, Jatek *jatek):&#160;init.c']]],
  ['initttf_159',['initTTF',['../init_8c.html#a7479fc03a6fa1d448a130e94760b01fe',1,'initTTF(char path[], int meret):&#160;init.c'],['../init_8h.html#a7479fc03a6fa1d448a130e94760b01fe',1,'initTTF(char path[], int meret):&#160;init.c']]]
];
