var searchData=
[
  ['jatekfrissites_160',['jatekFrissites',['../jatekmenet_8c.html#ae5be530bbfea7fb94a0f93d053c03a1a',1,'jatekFrissites(Peldany *jatekos, Jatek *jatek, Palya *palya, SDL_Texture *golyo, SDL_Texture *ellenseg, SDL_Texture *elet, SDL_Texture *tolteny, Lovedek **lovedek, PowerUp **powerup):&#160;jatekmenet.c'],['../jatekmenet_8h.html#a407f039e6efdb927ebe5d6df289667b1',1,'jatekFrissites(Peldany *jatekos, Jatek *jatek, Palya *palya, SDL_Texture *texture, SDL_Texture *ellenseg, SDL_Texture *elet, SDL_Texture *tolteny, Lovedek **lovedek, PowerUp **powerup):&#160;jatekmenet.c']]],
  ['jatekosfrissites_161',['jatekosFrissites',['../jatekmenet_8c.html#a2a8f1e5968d81f406b967878d4ee54bd',1,'jatekmenet.c']]]
];
