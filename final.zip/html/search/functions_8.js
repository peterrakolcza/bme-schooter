var searchData=
[
  ['kepernyo_162',['kepernyo',['../init_8c.html#a5c55e2174fe13673b2fc4b78b5f15b0c',1,'kepernyo(SDL_Renderer *renderer):&#160;init.c'],['../init_8h.html#a5c55e2174fe13673b2fc4b78b5f15b0c',1,'kepernyo(SDL_Renderer *renderer):&#160;init.c']]],
  ['kiiras_163',['kiiras',['../eredmenyek_8c.html#a49dd21f57a577ded931320b548f09abd',1,'kiiras(Eredmenyek tomb[]):&#160;eredmenyek.c'],['../eredmenyek_8h.html#a49dd21f57a577ded931320b548f09abd',1,'kiiras(Eredmenyek tomb[]):&#160;eredmenyek.c']]]
];
