var searchData=
[
  ['main_171',['main',['../main_8c.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main.c']]],
  ['mintazat_172',['mintazat',['../rajzolas_8c.html#aa53d004393e5249fb991c218cc71fe24',1,'rajzolas.c']]]
];
