var searchData=
[
  ['peldanyfrissites_173',['peldanyFrissites',['../jatekmenet_8c.html#a4c047dc54de141d5766990c8ed554540',1,'jatekmenet.c']]],
  ['powerupfrissites_174',['powerupFrissites',['../jatekmenet_8c.html#aba6f73627c2d24fae7c9043c09e8ced6',1,'jatekmenet.c']]],
  ['powerupletrehoz_175',['powerupLetrehoz',['../jatekmenet_8c.html#ab6b2d474726256cd4dbc87fabbb1145d',1,'jatekmenet.c']]]
];
