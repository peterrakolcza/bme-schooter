var searchData=
[
  ['rajz_176',['rajz',['../rajzolas_8c.html#a6fd0e900811519c1ff0d02c0c0a91d8c',1,'rajz(SDL_Texture *celzo, SDL_Texture *grid, SDL_Texture *hatter, Jatek *jatek, Peldany *jatekos, Lovedek *lovedek, PowerUp *powerup, Palya *palya, SDL_Renderer *renderer, TTF_Font *font):&#160;rajzolas.c'],['../rajzolas_8h.html#a6fd0e900811519c1ff0d02c0c0a91d8c',1,'rajz(SDL_Texture *celzo, SDL_Texture *grid, SDL_Texture *hatter, Jatek *jatek, Peldany *jatekos, Lovedek *lovedek, PowerUp *powerup, Palya *palya, SDL_Renderer *renderer, TTF_Font *font):&#160;rajzolas.c']]]
];
