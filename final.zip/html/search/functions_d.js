var searchData=
[
  ['spawnellenseg_177',['spawnEllenseg',['../jatekmenet_8c.html#a2d5b039c8924568620b8b643fdf8a55a',1,'jatekmenet.c']]],
  ['szog_178',['szog',['../jatekmenet_8c.html#a8fad92fd89a54b333dbf432d8371ce8d',1,'jatekmenet.c']]],
  ['szovegbeirasa_179',['szovegBeirasa',['../eredmenyek_8c.html#a937ff0b64af97202f6d091b4d42c1dde',1,'szovegBeirasa(Jatek *jatek, bool *vege):&#160;eredmenyek.c'],['../eredmenyek_8h.html#a937ff0b64af97202f6d091b4d42c1dde',1,'szovegBeirasa(Jatek *jatek, bool *vege):&#160;eredmenyek.c']]],
  ['szovegrajzolas_180',['szovegRajzolas',['../rajzolas_8c.html#a4bd2b513806bcf0cfe9e034074353102',1,'rajzolas.c']]]
];
