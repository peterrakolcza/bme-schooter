var searchData=
[
  ['tick_181',['tick',['../jatekmenet_8c.html#a3ec10aa72d10025566f4df4185027e05',1,'jatekmenet.c']]],
  ['torles_182',['torles',['../init_8c.html#a1dce24c6c71880df27dca2e22caf5af8',1,'torles(SDL_Renderer *renderer, SDL_Window *window):&#160;init.c'],['../init_8h.html#a1dce24c6c71880df27dca2e22caf5af8',1,'torles(SDL_Renderer *renderer, SDL_Window *window):&#160;init.c']]]
];
