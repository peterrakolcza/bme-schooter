var searchData=
[
  ['eger_222',['Eger',['../kozos_8h.html#a5a185307919924584e258213c5bdc413',1,'kozos.h']]],
  ['eredmenyek_223',['Eredmenyek',['../kozos_8h.html#a25b675797368da2771e6624d4f82c969',1,'kozos.h']]]
];
