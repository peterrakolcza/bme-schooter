var searchData=
[
  ['fegyver_224',['Fegyver',['../kozos_8h.html#af9275be7cde56e11f0400be4a8d35296',1,'kozos.h']]]
];
