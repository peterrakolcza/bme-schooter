var searchData=
[
  ['jatek_225',['Jatek',['../kozos_8h.html#a135b13c622a4434f9f2e8895f1f4b709',1,'kozos.h']]]
];
