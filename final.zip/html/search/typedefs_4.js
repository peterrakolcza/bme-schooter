var searchData=
[
  ['lovedek_226',['Lovedek',['../kozos_8h.html#a550ab1650a2ac0c47502400b86048890',1,'kozos.h']]]
];
