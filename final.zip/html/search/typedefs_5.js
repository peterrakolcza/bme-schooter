var searchData=
[
  ['palya_227',['Palya',['../kozos_8h.html#aed8de916f807ff6e7fe953593a327555',1,'kozos.h']]],
  ['peldany_228',['Peldany',['../kozos_8h.html#a682e744424a5e081acfb38a9234ac567',1,'kozos.h']]],
  ['powerup_229',['PowerUp',['../kozos_8h.html#a80413c65dfc2583386bac5300021137c',1,'kozos.h']]]
];
