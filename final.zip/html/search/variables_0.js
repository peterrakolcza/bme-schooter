var searchData=
[
  ['beszoveg_183',['beSzoveg',['../struct_jatek.html#aaf5bf7e32c634ca91179689048cfb999',1,'Jatek']]],
  ['billentyuzet_184',['billentyuzet',['../struct_jatek.html#a3d5f0c3375fc3fc2f5814ad9497a44f5',1,'Jatek']]]
];
