var searchData=
[
  ['dx_185',['dx',['../struct_peldany.html#a9eae6c1f38db98ab568f3ed3771a969d',1,'Peldany::dx()'],['../struct_power_up.html#a9eae6c1f38db98ab568f3ed3771a969d',1,'PowerUp::dx()'],['../struct_lovedek.html#a9eae6c1f38db98ab568f3ed3771a969d',1,'Lovedek::dx()']]],
  ['dy_186',['dy',['../struct_peldany.html#a8f461b6142ce8725218813abb23b06a3',1,'Peldany::dy()'],['../struct_power_up.html#a8f461b6142ce8725218813abb23b06a3',1,'PowerUp::dy()'],['../struct_lovedek.html#a8f461b6142ce8725218813abb23b06a3',1,'Lovedek::dy()']]]
];
