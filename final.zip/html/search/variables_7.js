var searchData=
[
  ['line_199',['line',['../struct_debugmalloc_elem.html#a05ef0c4dbeec4fc8ccb225de9c26d896',1,'DebugmallocElem']]],
  ['logfile_200',['logfile',['../struct_debugmalloc_data.html#af5ff893eedb28514f6f69c3687ca893b',1,'DebugmallocData']]]
];
