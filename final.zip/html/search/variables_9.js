var searchData=
[
  ['oldal_203',['oldal',['../struct_peldany.html#ab375ec7f47c62b6ec480e6399236e567',1,'Peldany::oldal()'],['../struct_power_up.html#ab375ec7f47c62b6ec480e6399236e567',1,'PowerUp::oldal()'],['../struct_lovedek.html#ab375ec7f47c62b6ec480e6399236e567',1,'Lovedek::oldal()']]]
];
