var searchData=
[
  ['pont_204',['pont',['../struct_palya.html#a6670730859644bce5055578d24c9ff6a',1,'Palya']]],
  ['pontszam_205',['pontSzam',['../struct_eredmenyek.html#af1c0fdf470465a46883498c230e81f0c',1,'Eredmenyek']]],
  ['prev_206',['prev',['../struct_debugmalloc_elem.html#aa4c400384a867d19fb42dd9a64ebf249',1,'DebugmallocElem']]]
];
