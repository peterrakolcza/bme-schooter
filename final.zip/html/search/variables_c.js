var searchData=
[
  ['size_208',['size',['../struct_debugmalloc_elem.html#a854352f53b148adc24983a58a1866d66',1,'DebugmallocElem']]],
  ['spawnidozito_209',['spawnIdozito',['../struct_palya.html#a10254401739f948a8c706a6bdb1d5728',1,'Palya']]],
  ['szog_210',['szog',['../struct_peldany.html#acf721b2887c9dab2acedce755a6b29ec',1,'Peldany::szog()'],['../struct_lovedek.html#acf721b2887c9dab2acedce755a6b29ec',1,'Lovedek::szog()']]]
];
