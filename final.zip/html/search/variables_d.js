var searchData=
[
  ['tail_211',['tail',['../struct_debugmalloc_data.html#addc8e0dcf96cbf596961383aabf9ec97',1,'DebugmallocData']]],
  ['texture_212',['texture',['../struct_peldany.html#a859b8efbf9abe8e82757ee5c75a0c97c',1,'Peldany::texture()'],['../struct_power_up.html#a859b8efbf9abe8e82757ee5c75a0c97c',1,'PowerUp::texture()'],['../struct_lovedek.html#a859b8efbf9abe8e82757ee5c75a0c97c',1,'Lovedek::texture()']]],
  ['tipus_213',['tipus',['../struct_power_up.html#a79399c4d986e6b87e222cbf38b392913',1,'PowerUp']]],
  ['tolteny_214',['tolteny',['../struct_palya.html#ae4ef33e0e2ef855554f77eabb40c73a9',1,'Palya']]]
];
