var struct_debugmalloc_data =
[
    [ "head", "struct_debugmalloc_data.html#a173f22b0572bd92dd1267afba8ba0d6c", null ],
    [ "logfile", "struct_debugmalloc_data.html#af5ff893eedb28514f6f69c3687ca893b", null ],
    [ "tail", "struct_debugmalloc_data.html#addc8e0dcf96cbf596961383aabf9ec97", null ]
];