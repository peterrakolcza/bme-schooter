var struct_debugmalloc_elem =
[
    [ "expr", "struct_debugmalloc_elem.html#aa8f5b6d2256e18de50b9a17b5e3cda3b", null ],
    [ "file", "struct_debugmalloc_elem.html#a353d29f9f9cc0db6fca9d49b5f88d34d", null ],
    [ "func", "struct_debugmalloc_elem.html#ac8a2334cf5c64b1f708ced23ef569db4", null ],
    [ "line", "struct_debugmalloc_elem.html#a05ef0c4dbeec4fc8ccb225de9c26d896", null ],
    [ "next", "struct_debugmalloc_elem.html#a485117ad705ab85f760fa96176f5825a", null ],
    [ "prev", "struct_debugmalloc_elem.html#aa4c400384a867d19fb42dd9a64ebf249", null ],
    [ "real_mem", "struct_debugmalloc_elem.html#ae241706d126e0114e48ce7c4083d93d1", null ],
    [ "size", "struct_debugmalloc_elem.html#a854352f53b148adc24983a58a1866d66", null ],
    [ "user_mem", "struct_debugmalloc_elem.html#a20cf96b6c21400f0123a6a3b6dae9876", null ]
];