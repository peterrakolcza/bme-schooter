var struct_eger =
[
    [ "gomb", "struct_eger.html#a12b25b5cc4e522f0ecda03f294d62d26", null ],
    [ "gorgo", "struct_eger.html#ac948d2cd07ec2931bb302cb2e5a63aa0", null ],
    [ "x", "struct_eger.html#a6150e0515f7202e2fb518f7206ed97dc", null ],
    [ "y", "struct_eger.html#a0a2f84ed7838f07779ae24c5a9086d33", null ]
];