var struct_eredmenyek =
[
    [ "nev", "struct_eredmenyek.html#a074ffd3ef2ad10d0979161d59df06d07", null ],
    [ "pontSzam", "struct_eredmenyek.html#af1c0fdf470465a46883498c230e81f0c", null ]
];