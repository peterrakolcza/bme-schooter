var struct_jatek =
[
    [ "beSzoveg", "struct_jatek.html#aaf5bf7e32c634ca91179689048cfb999", null ],
    [ "billentyuzet", "struct_jatek.html#a3d5f0c3375fc3fc2f5814ad9497a44f5", null ],
    [ "eger", "struct_jatek.html#afcbe7770c7cbf43a3aa7590a6393480d", null ]
];