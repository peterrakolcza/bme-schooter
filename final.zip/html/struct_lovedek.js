var struct_lovedek =
[
    [ "dx", "struct_lovedek.html#a9eae6c1f38db98ab568f3ed3771a969d", null ],
    [ "dy", "struct_lovedek.html#a8f461b6142ce8725218813abb23b06a3", null ],
    [ "elet", "struct_lovedek.html#a90513b7198bdc6bbbda76ba497f37ff1", null ],
    [ "h", "struct_lovedek.html#a16611451551e3d15916bae723c3f59f7", null ],
    [ "hatokor", "struct_lovedek.html#a9211d2faa24d673f8dfacf777f7325b2", null ],
    [ "kov", "struct_lovedek.html#a5d11984f43577221fcba4fccf49cf14a", null ],
    [ "oldal", "struct_lovedek.html#ab375ec7f47c62b6ec480e6399236e567", null ],
    [ "szog", "struct_lovedek.html#acf721b2887c9dab2acedce755a6b29ec", null ],
    [ "texture", "struct_lovedek.html#a859b8efbf9abe8e82757ee5c75a0c97c", null ],
    [ "w", "struct_lovedek.html#aac374e320caaadeca4874add33b62af2", null ],
    [ "x", "struct_lovedek.html#ad0da36b2558901e21e7a30f6c227a45e", null ],
    [ "y", "struct_lovedek.html#aa4f0d3eebc3c443f9be81bf48561a217", null ]
];