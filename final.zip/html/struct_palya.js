var struct_palya =
[
    [ "pont", "struct_palya.html#a6670730859644bce5055578d24c9ff6a", null ],
    [ "spawnIdozito", "struct_palya.html#a10254401739f948a8c706a6bdb1d5728", null ],
    [ "tolteny", "struct_palya.html#ae4ef33e0e2ef855554f77eabb40c73a9", null ]
];