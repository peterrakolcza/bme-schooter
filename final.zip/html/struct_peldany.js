var struct_peldany =
[
    [ "dx", "struct_peldany.html#a9eae6c1f38db98ab568f3ed3771a969d", null ],
    [ "dy", "struct_peldany.html#a8f461b6142ce8725218813abb23b06a3", null ],
    [ "elet", "struct_peldany.html#a90513b7198bdc6bbbda76ba497f37ff1", null ],
    [ "fegyver", "struct_peldany.html#a01c600a575ec89d64a85336929d4deb0", null ],
    [ "h", "struct_peldany.html#a16611451551e3d15916bae723c3f59f7", null ],
    [ "hatokor", "struct_peldany.html#a9211d2faa24d673f8dfacf777f7325b2", null ],
    [ "kov", "struct_peldany.html#a5dd3001677caf0537f6f3dcfb903d766", null ],
    [ "oldal", "struct_peldany.html#ab375ec7f47c62b6ec480e6399236e567", null ],
    [ "szog", "struct_peldany.html#acf721b2887c9dab2acedce755a6b29ec", null ],
    [ "texture", "struct_peldany.html#a859b8efbf9abe8e82757ee5c75a0c97c", null ],
    [ "ujratoltIdo", "struct_peldany.html#a5146dcb636620ac1284604ca73335923", null ],
    [ "w", "struct_peldany.html#aac374e320caaadeca4874add33b62af2", null ],
    [ "x", "struct_peldany.html#ad0da36b2558901e21e7a30f6c227a45e", null ],
    [ "y", "struct_peldany.html#aa4f0d3eebc3c443f9be81bf48561a217", null ]
];