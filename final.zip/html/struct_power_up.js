var struct_power_up =
[
    [ "dx", "struct_power_up.html#a9eae6c1f38db98ab568f3ed3771a969d", null ],
    [ "dy", "struct_power_up.html#a8f461b6142ce8725218813abb23b06a3", null ],
    [ "elet", "struct_power_up.html#a90513b7198bdc6bbbda76ba497f37ff1", null ],
    [ "h", "struct_power_up.html#a16611451551e3d15916bae723c3f59f7", null ],
    [ "hatokor", "struct_power_up.html#a9211d2faa24d673f8dfacf777f7325b2", null ],
    [ "kov", "struct_power_up.html#af9c2d469f617545127cfd0667354f9a2", null ],
    [ "oldal", "struct_power_up.html#ab375ec7f47c62b6ec480e6399236e567", null ],
    [ "texture", "struct_power_up.html#a859b8efbf9abe8e82757ee5c75a0c97c", null ],
    [ "tipus", "struct_power_up.html#a79399c4d986e6b87e222cbf38b392913", null ],
    [ "w", "struct_power_up.html#aac374e320caaadeca4874add33b62af2", null ],
    [ "x", "struct_power_up.html#ad0da36b2558901e21e7a30f6c227a45e", null ],
    [ "y", "struct_power_up.html#aa4f0d3eebc3c443f9be81bf48561a217", null ]
];